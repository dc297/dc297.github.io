# html5 resume 

modified variant of slide format and styles from: 

reveal.js
https://github.com/hakimel/reveal.js

License
MIT licensed
Copyright (C) 2011 Hakim El Hattab, http://hakim.se